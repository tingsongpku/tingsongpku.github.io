The dataset (chronicle_dataset.txt) is constructed from 2009-2010 APW and XIN news stories in English Gigaword 5th version [1] (available from the LDC). It does not include documents whose title and first paragraph do not contain any burst word.

The dataset contains 140,557 news articles in total. Each line is one document ID. It can be used as a dataset for evaluating topically relevant event chronicle generation task[2].

References:
[1] Graff et al.: English gigaword. Linguistic Data Consortium, Philadelphia (2003).
[2] Ge et al.: Bring you to the past: Automatic Generation of Topically Relevant Event Chronicles. In ACL 2015.

